
var v_debug = true;
var v_num=0;
var num =0;
var item_num =0;
function f_arrange(){
    for(var i=1; i<=4; i++){
        for(var j = 1; j<=7; j++){
        $("<div>").css("grid-column-start",j)
                  .css("grid-column-end", j+1 )
                  .css("grid-row-start",i)
                  .css("grid-row-end",i+1)
                  .addClass("cl_pan hexagon arr"+i)
                  .appendTo($(".arrange"))
                  .on("dragover",function(){
                    event.preventDefault();
                  })
                  .on("drop",function(){
                      event.preventDefault();
                      console.log(this)
                      f_devent(this);
                  })
                  
        }
    }
}

function f_devent(p_this){
    var v_id= event.dataTransfer.getData("ngm");
        if(event.dataTransfer.getData("new")){
            return;     
        }
        v_clone = document.getElementById(v_id).cloneNode(true);
        console.log(p_this)
        console.log(document.styleSheets[1].cssRules[1].style.backgroundImage=v_clone.style.backgroundImage)
        console.log(v_clone.id)
        p_this.style.backgroundImage = v_clone.style.backgroundImage
        p_this.style.borderColor = v_clone.style.borderColor
        p_this.style.bordrSize= "2px"
        document.styleSheets[1].cssRules[1].style.backgroundImage
        = "url(../images/cham/"+v_clone.id+".png)"
        // p_this.appendChild(v_clone)
}


var v_arslot = document.querySelectorAll(".cl_pan")
if(v_debug){
    console.log(v_arslot); //판하나하나
}

  for(var i=0; i<v_arslot.length; i++){
      v_arslot[i].addEventListener("drop",function(){
        event.preventDefault();
        console.log(this)
      })
      
  }