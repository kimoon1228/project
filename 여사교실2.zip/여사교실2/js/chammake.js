var chaName=
"가렌,그라가스,노틸러스,녹턴,누누와 윌럼프,니달리,다리우스,다이애나,드레이븐,"+
"라이즈,럭스,레오나,렐,룰루,르블랑,리 신,리븐,리산드라,모데카이저,모르가나,"+
"바루스,베인,벨코즈,볼리베어,브랜드,블라디미르,비에고,빅토르,뽀삐,세주아니,"+
"세트,소라카,신드라,쓰레쉬,아이번,아트록스,아펠리오스,애쉬,야스오,우디르,워윅,"+
"자이라,잭스,직스,카르마,카직스,카타리나,칼리스타,케넨,케일,클레드,킨드레드,"+
"타릭,트런들,티모,판테온,하이머딩거,헤카림"

var cost1 =
"그라가스,레오나,리산드라,베인,블라디미르,뽀삐,아트록스,우디르,워윅,직스,카직스,칼리스타,클레드";
var cost2 = "노틸러스,르블랑,바루스,브랜드,빅토르,세주아니,세트,소라카,신드라,쓰레쉬"+
"케넨,트런들,헤카림"
var cost3 = "녹턴,누누와 윌럼프,니달리,럭스,룰루,리 신,리븐,모르가나,애쉬,야스오,자이라,카타리나,판테온"
var cost4 = "다이애나,드레이븐,라이즈,렐,벨코즈,아이번,아펠리오스,잭스,카르마,타릭"
var cost5 = "가렌,다리우스,볼리베어,비에고,케일,킨드레드,티모,하이머딩거"

var v_line = {};
 v_line.Abomination= ["칼리스타","브랜드","누누와 윌럼프","라이즈"]
 v_line.Redeemed = ["아트록스","레오나","바루스","신드라","럭스","렐","벨코즈","케일"]
 v_line.Forgotten = ["워윅","베인","빅토르","쓰레쉬","헤카림","카타리나","드레이븐","라이즈","비에고"]
 v_line.Revenant = ["녹턴","아이번","볼리베어"]
 v_line.Dawnbringer = ["카직스","그라가스","소라카","니달리","리븐","카르마","가렌"]
 v_line.Verdant = ["애쉬","타릭","케일"]
 v_line.Hellion = ["뽀삐","직스","클레드","케넨","룰루","티모"]
 v_line.Coven = ["리산드라","르블랑","모르가나"]
 v_line.Nightbringer = ["블라디미르","세주아니","리 신","모르가나","야스오","다이애나","아펠리오스","다리우스"]
 v_line.Eternal = "킨드레드"
 v_line.Dragonslayer = ["트런들","판테온","다이애나","모데카이저"]
 v_line.Draconic = ["우디르","세트","애쉬","자이라","하이머딩거"]
 v_line.Ironclad = ["노틸러스","렐","잭스"]
console.log(v_line)
var v_job ={};
v_job.Legionnaire = ["아트록스","칼리스타","리븐","야스오","드레이븐","모데카이저","케일"]
v_job.Cruel = "티모"
v_job.Cavalier = ["클레드","세주아니","헤카림","렐"]
v_job.Knight = ["레오나","뽀삐","노틸러스","쓰레쉬","타릭","가렌","다리우스"]
v_job.Invoker = ["신드라","아이번","카르마","티모"]
v_job.Mystic = ["룰루","럭스","모르가나","라이즈","킨드레드"]
v_job.GodKing = ["가렌","다리우스"]
v_job.Brawler = ["그라가스","워윅","세트","누누와 윌럼프","볼리베어"]
v_job.Assassin = ["카직스","르블랑","녹턴","카타리나","다이애나","비에고"]
v_job.Renewer = ["리산드라","블라디미르","소라카","아이번","하이머딩거"]
v_job.Ranger = ["베인","바루스","애쉬","아펠리오스","킨드레드"]
v_job.Caretaker = "하이머딩거"
v_job.Spellweaver = ["직스","빅토르","브랜드","자이라","벨코즈"]
v_job.Skirmisher = ["우디르","케넨","트런들","니달리","리 신","판테온","잭스","비에고"]
//  console.log(v_job)

chaName= chaName.split(",");
cost1=cost1.split(",");
cost2=cost2.split(",");
cost3=cost3.split(",");
cost4=cost4.split(",");
cost5=cost5.split(",");
var cham ={};
cham.id=[]
cham.png=[];
cham.name=[];
cham.cost=[];
cham.synerge={};
cham.synerge.line =[];
cham.synerge.job=[];

var v_bordercolor =["green","blue","blueviolet","yellow"]

//기물 Json 만들기 
function editpic(){
   for(var i=0; i<58; i++){
       cham.png[i]="./images/cham/"+(i)+".png"; 
       cham.id[i]=i    
    }
    for(var j=0; j<chaName.length; j++ ){
        cham.name[j]=chaName[j];
    }
    return cham
}
console.log(cham)
editpic();
// 만든 Json별 코스트 먹이기
function costEdit(){
    for(var i=0;i<cham.name.length; i++){
        for(var a=0;a<cost1.length; a++){
            if(cham.name[i]==cost1[a]){
                cham.cost[i]=1;
            }
        }
        for(var b=0;b<cost2.length; b++){
            if(cham.name[i]==cost2[b]){
                cham.cost[i]=2
            }
        }
        for(var c=0;c<cost3.length; c++){
            if(cham.name[i]==cost3[c]){
                cham.cost[i]=3
            }
        }
        for(var d=0;d<cost4.length; d++){
            if(cham.name[i]==cost4[d]){
                cham.cost[i]=4
            }
        }
        for(var e=0;e<cost5.length; e++){
            if(cham.name[i]==cost5[e]){
                cham.cost[i]=5
            }
        }
    }
    return cham
}
 
// 이름별 기물 출력
function f_make(){
    costEdit();
    v_chamSlot.innerHTML="";
    for(var i=0; i<cham.png.length;i++){
    var v_div = document.createElement("div");
    v_div.style.backgroundImage ="url("+cham.png[i]+")"
    v_div.style.borderColor = f_bocolor(cham.cost[i])
    v_div.title = cham.name[i];
    v_div.innerHTML=cham.name[i].substr(0,5);
    v_div.setAttribute("class","cl_can");
    v_div.setAttribute("id",cham.id[i]);
    v_div.draggable=true;
    v_div.ondragstart = function(){
        event.dataTransfer.setData("ngm",event.target.id);
        // console.log(event.target);
    }
    v_chamSlot.appendChild(v_div)
}
}

// 코스트별 bordercolor
function f_bocolor(v_cost){
    if(v_cost==1){
        return
    }
    for(var i=0; i<v_bordercolor.length;i++){
        if(v_cost==2){
            return v_bordercolor[0];
        }if(v_cost==3){
            return v_bordercolor[1];
        }if(v_cost==4){
            return v_bordercolor[2];
        }if(v_cost==5){
            return v_bordercolor[3];
        }
    }
}
// 가격별 정렬 기물 출력
function f_sort(){
    v_chamSlot.innerHTML="";
    for(var i=1; i<=5; i++){
        for(var j=1; j<cham.png.length;j++){
            if(cham.cost[j]==i){
            var v_div = document.createElement("div");
            v_div.setAttribute("id","ngm"+ i + j);
            v_div.style.backgroundImage ="url("+cham.png[j]+")"
            v_div.style.borderColor = f_bocolor(cham.cost[j])
            v_div.title = cham.name[j];
            v_div.innerHTML=cham.name[j].substr(0,5);
            v_div.draggable=true;
            v_div.setAttribute("class","cl_can");
            v_div.ondragstart = function(){
                event.dataTransfer.setData("ngm",event.target.id);
                // console.log(event.target);
            }
            v_chamSlot.appendChild(v_div)
            }
        }
    }
}
    
// 시너지 먹이기
function f_linesynerge(){
    for(var c=0; c<cham.name.length;c++){
        cham.synerge.line[c]=[]
        // console.log(cham.name[c]) 총 챔프 이름 확인
        if(cham.name[c]=="킨드레드"){
            cham.synerge.line[c][cham.synerge.line[c].length]="영겁"
            continue;
        }
        for(var a in v_line){
        // console.log(v_line[a]) 시너지 확인
        // console.log(a); 시너지 값
            for(var b=0; b<v_line[a].length;b++){
            // console.log(v_line[a][b])시너지별 챔피언 이름 확인
                if(cham.name[c]==v_line[a][b]){

                    if(a== "Abomination"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "괴생명체"
                    }
                    else if(a== "Redeemed"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "구원받은 자"
                    }
                    else if(a== "Forgotten"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "망각"
                    }
                    else if(a== "Revenant"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "망령"
                    }
                    else if(a== "Dawnbringer"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "빛의 인도자"
                    }
                    else if(a== "Verdant"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "신록"
                    }
                    else if(a== "Hellion"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "악동"
                    }
                    else if(a== "Coven"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "악의 여단"
                    }
                    else if(a== "Nightbringer"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "어둠의인도자"
                    }
                    else if(a== "Dragonslayer"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "용 사냥꾼"
                    }
                    else if(a== "Draconic"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "용족"
                    }
                    else if(a== "Ironclad"){
                    cham.synerge.line[c][cham.synerge.line[c].length] = "철갑"
                    }
                }
            }
        }
    }
}
       f_linesynerge()

       function f_jobsynerge(){
        for(var c=0; c<cham.name.length;c++){
            cham.synerge.job[c]=[]
            if(cham.name[c]=="티모"){
                cham.synerge.job[c][cham.synerge.job[c].length] = "극악무도"
            }
            else if(cham.name[c]=="하이머딩거"){
                cham.synerge.job[c][cham.synerge.job[c].length] = "조련사"
                continue;
            }
            for(var a in v_job){
                // console.log(v_job[a]) 시너지 확인 
                // console.log(a) 시너지 값 확인
                for(var b=0; b<v_job[a].length;b++){
                    if(cham.name[c]==v_job[a][b]){
                        if(a== "Legionnaire"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "군단"
                        }
                        else if(a== "Cavalier"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "기병대"
                        } 
                        else if(a== "Knight"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "기사"
                        }
                        else if(a== "Invoker"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "기원자"
                        }
                        else if(a== "Mystic"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "신비술사"
                        }
                        else if(a== "GodKing"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "신왕"
                        }
                        else if(a== "Brawler"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "싸움꾼"
                        }
                        else if(a== "Assassin"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "암살자"
                        }
                        else if(a== "Renewer"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "재생술사"
                        }
                        else if(a== "Ranger"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "정찰대"
                        }
                        else if(a== "Spellweaver"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "주문술사"
                        }
                        else if(a== "Skirmisher"){
                            cham.synerge.job[c][cham.synerge.job[c].length] = "척후병"
                        }   
                    }
                }
            }
        }
    }

    f_jobsynerge()