
function f_itemshowing(){
    
}