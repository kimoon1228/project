var push_sy=[]
var v_sy_container = document.createElement("div");
    v_sy_container.setAttribute("id","sycontainer")
            function f_synerge(p_clone){
                
                // console.log(p_clone) // div안의 값
                for(var a =0; a<push_sy.length; a++){ //  시너지 확인용 배열이 이미 담겨있으면 리턴
                    if(push_sy[a].title==p_clone.title)
                    return
                }
                push_sy[push_sy.length]=p_clone; // 없으면 배열에 넣기
                // console.log(push_sy[0].title) // 배열안에 들어간내용의 타이틀
                // console.log(cham.name) // 챔피언 이름배열
                for(var j=1; j<cham.name.length; j++){ // 0번은 없음
                    for(var i =0; i<push_sy.length; i++){
                        if(cham.name[j]==push_sy[i].title){
                            // console.log(cham.synerge[j]); //해당하는 시너지 출력 확인
                            v_synerge.style.border="";
                            // console.log(v_synerge.children[0].id) 시너지박스 자식의 아이디 확인
                            if(v_synerge.children[0].id == "basicdiv"){ // 기본문구 일때 기본문구 삭제
                                v_synerge.innerHTML= "";
                            }for(var k = 0; k<cham.synerge[j].length; k++){
                                var sy_box = document.createElement("div");
                                var cnt = 1;
                                sy_box.setAttribute("id",cham.synerge[j][k])
                                sy_box.innerHTML = sy_box.id ;
                                sy_box.innerHTML += cnt
                                console.log(v_sy_container.childElementCount)
                                for(var b=0; b<v_sy_container.childElementCount; b++){
                                    console.log(v_sy_container.children[b].id)
                                    if(v_sy_container.children[b].id==sy_box.id){
                                        v_sy_container.children[b].innerHTML=""
                                        v_sy_container.children[b].innerHTML= sy_box.id;
                                        
                                    }
                                    }
                                }
                                v_sy_container.appendChild(sy_box)
                        }

                    }
                }    
                v_synerge.appendChild(v_sy_container)
            }


