var chaName=
"가렌,나서스,노틸러스,누누와윌럼프,니달리,니코,다리우스,다이애나,라칸,룰루,"+
"리신,마오카이,모르가나,바이,베이가,브라움,브랜드,블라디미르,사미라,세주아니,"+
"세트,쉔,쉬바나,스웨인,시비르,아우렐리온 솔,아지르,아칼리,아트록스,애니,"+
"야스오,엘리스,오공,오른,올라프,요네,유미,이렐리아,자르반 4세,자야,"+
"잔나,잭스,제드,질리언,초가스,카타리나,칼리스타,케넨,케일,킨드레드,"+
"탈론,탐 켄치,트리스타나,트린다미어,트위스티드 페이트,티모,파이크,피오라"

var cost1 =
"가렌,나서스,니달리,다이애나,마오카이,브랜드,야스오,엘리스,오공,탐 켄치,"+
"트리스타나,트위스티드 페이트,피오라";
var cost2 = "노틸러스,라칸,룰루,바이,브라움,블라디미르,애니,자르반 4세,잔나,잭스,"+
"제드,티모,파이크"
var cost3 = "누누와윌럼프,니코,다리우스,베이가,쉬바나,시비르,아칼리,유미,이렐리아,카타리나,칼리스타,케넨,킨드레드"
var cost4 = "모르가나,세주아니,쉔,아우렐리온 솔,아트록스,올라프,자야,초가스,케일,탈론,트린다미어"
var cost5 = "리신,사미라,세트,스웨인,아지르,오른,요네,질리언"

var v_line = []
var sindo = "트위스티드 페이트,엘리스,블라디미르,파이크,시비르,칼리스타,아트록스,질리언"
var wood = "마오카이,라칸,룰루,누누와윌럼프,베이가,자야,오른"
var ninja = "제드,아칼리,케넨,쉔"
var warload = "가렌,니달리,바이,자르반,카타리나,트린다미어,아지르"
var mumo = "사미라"
var sunji = "피오라,잔나,이렐리아,모르가나,탈론"
var holy = "나서스,오공,잭스,이렐리아,케일,리신"
var soul = "다이애나,티모,유미,킨드레드"
var dragon = "트리스타나,브랜드,브라움,쉬바나,아우렐리온 솔,올라프,스웨인"
var head = "세트"
var wohwa = "노틸러스,니코,초가스"
var exile = "야스오,요네"
var lucky = "탐 켄치,애니,다리우스,카타리나,세주아니"
 v_line[v_line.length] = sindo.split(",");
 v_line[v_line.length] = wood.split(",");
 v_line[v_line.length] = ninja.split(",");
 v_line[v_line.length] = warload.split(",");
//  v_line[v_line.length] = mumo;
 v_line[v_line.length] = sunji.split(",");
 v_line[v_line.length] = holy.split(",");
 v_line[v_line.length] = soul.split(",");
 v_line[v_line.length] = dragon.split(",");
//  v_line[v_line.length] = head
 v_line[v_line.length] = wohwa.split(",");
 v_line[v_line.length] = exile.split(",");
 v_line[v_line.length] = lucky.split(",");
// console.log(v_line)
var v_job =[];
var dual = "야스오,피오라,잭스,칼리스타,트린다미어,리신"
var Model = "엘리스,라칸,자르반,케넨,자야,아지르"
var blacksmith ="오른"
var shooter = "니달리,트리스타나,티모,시비르,사미라"
var garder = "가렌,오공,노틸러스,브라움,세주아니,아트록스,오른"
var sinbi = "잔나,니코,유미,쉔,질리언"
var fighter = "탐 켄치,마오카이,바이,누누와윌럼프,쉬바나,초가스,세트"
var assassin ="다이애나,파이크,아칼리,카타리나,탈론"
var witch = "브랜드,트위스티드 페이트,룰루,애니,베이가,아우렐리온 솔"
var tuning = "이렐리아,쉔,요네"
var execution = "킨드레드,자야,케일"
var slaughter = "제드,파이크,다리우스,올라프,트린다미어,사미라"
var king = "아지르"
var abs = "나서스,블라디미르,모르가나,스웨인"
v_job[v_job.length] = dual.split(",");
v_job[v_job.length] = Model.split(",");
v_job[v_job.length] = shooter.split(",");
v_job[v_job.length] = garder.split(",");
v_job[v_job.length] = sinbi.split(",");
v_job[v_job.length] = fighter.split(",");
v_job[v_job.length] = assassin.split(",");
v_job[v_job.length] = witch.split(",");
v_job[v_job.length] = tuning.split(",");
v_job[v_job.length] = execution.split(",");
v_job[v_job.length] = slaughter.split(",")
v_job[v_job.length] = abs.split(",")
// console.log(v_job)

chaName= chaName.split(",");
cost1=cost1.split(",");
cost2=cost2.split(",");
cost3=cost3.split(",");
cost4=cost4.split(",");
cost5=cost5.split(",");
var cham ={};
cham.png=[];
cham.name=[];
cham.cost=[];
cham.synerge=[];

console.log()
var v_bordercolor =["green","blue","blueviolet","yellow"]

//기물 Json 만들기 
function editpic(){
   for(var i=0; i<58; i++){
       cham.png[i+1]="./images/"+(i+1)+".png";     
    }
    for(var j=0; j<chaName.length; j++ ){
        cham.name[j+1]=chaName[j];
    }
    return cham
}
editpic();
// 만든 Json별 코스트 먹이기
function costEdit(){
    for(var i=1;i<=cham.name.length; i++){
        for(var a=0;a<cost1.length; a++){
            if(cham.name[i]==cost1[a]){
                cham.cost[i]=1;
            }
        }
        for(var b=0;b<cost2.length; b++){
            if(cham.name[i]==cost2[b]){
                cham.cost[i]=2
            }
        }
        for(var c=0;c<cost3.length; c++){
            if(cham.name[i]==cost3[c]){
                cham.cost[i]=3
            }
        }
        for(var d=0;d<cost4.length; d++){
            if(cham.name[i]==cost4[d]){
                cham.cost[i]=4
            }
        }
        for(var e=0;e<cost5.length; e++){
            if(cham.name[i]==cost5[e]){
                cham.cost[i]=5
            }
        }
    }
    return cham
}
 
// 이름별 기물 출력
function f_make(){
    costEdit();
    ware.innerHTML="";
    for(var i=1; i<cham.png.length;i++){
    var v_div = document.createElement("div");
    v_div.style.backgroundImage ="url("+cham.png[i]+")"
    v_div.style.borderColor = f_bocolor(cham.cost[i])
    v_div.title = cham.name[i];
    v_div.innerHTML=cham.name[i].substr(0,5);
    v_div.setAttribute("class","cl_can");
    v_div.setAttribute("id","ngm"+ cham.cost[i]+i);
    v_div.draggable=true;
    v_div.ondragstart = function(){
        event.dataTransfer.setData("ngm",event.target.id);
        // console.log(event.target);
        console.log(v_unit)
    }
    ware.appendChild(v_div)
}
}

// 코스트별 bordercolor
function f_bocolor(v_cost){
    if(v_cost==1){
        return
    }
    for(var i=0; i<v_bordercolor.length;i++){
        if(v_cost==2){
            return v_bordercolor[0];
        }if(v_cost==3){
            return v_bordercolor[1];
        }if(v_cost==4){
            return v_bordercolor[2];
        }if(v_cost==5){
            return v_bordercolor[3];
        }
    }
}

// 가격별 정렬 기물 출력
function f_sort(){
    ware.innerHTML="";
    for(var i=1; i<=5; i++){
        for(var j=1; j<cham.png.length;j++){
            if(cham.cost[j]==i){
            var v_div = document.createElement("div");
            v_div.setAttribute("id","ngm"+ i + j);
            v_div.style.backgroundImage ="url("+cham.png[j]+")"
            v_div.style.borderColor = f_bocolor(cham.cost[j])
            v_div.title = cham.name[j];
            v_div.innerHTML=cham.name[j].substr(0,5);
            v_div.draggable=true;
            v_div.setAttribute("class","cl_can");
            v_div.ondragstart = function(){
                event.dataTransfer.setData("ngm",event.target.id);
                // console.log(event.target);
            }
            ware.appendChild(v_div)
            }
        }
    }
}
    
// 시너지 먹이기
function f_linesynerge(){
       for(var i=0; i<v_line.length; i++){
        for(var k= 0; k<v_line[i].length; k++){
           for(var j= 1; j<cham.name.length; j++){
               if(cham.name[j]==v_line[i][k]){
                   if(i==0){
                       cham.synerge[j]=[]
                       cham.synerge[j][cham.synerge[j].length]="광신도"; 
                    }
                   if(i==1){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="나무정령";
                    }
                   if(i==2){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="닌자";
                    }
                   if(i==3){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="대장군";
                    }
                   if(i==4){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="선지자";
                    }
                   if(i==5){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="신성";
                    }
                   if(i==6){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="영혼";
                    }
                   if(i==7){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="용의영혼";
                    }
                   if(i==8){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="우화";
                    }
                   if(i==9){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="추방자";
                    }
                   if(i==10){
                        cham.synerge[j]=[]
                        cham.synerge[j][cham.synerge[j].length]="행운";
                    }
               }
               if(cham.name[j]=="사미라"){
                    cham.synerge[j]=[]
                    cham.synerge[j][cham.synerge[j].length]="무모한자";
                }
                if(cham.name[j]=="세트"){
                    cham.synerge[j]=[]
                    cham.synerge[j][cham.synerge[j].length]="우두머리";
                }
           }
       }
    }
}
    f_linesynerge();
    // console.log(v_job[0][0].length)
    function f_jobsynerge(){
        for(var i=0; i<v_job.length; i++){
         for(var k= 0; k<v_job[i].length; k++){
            for(var j= 1; j<cham.name.length; j++){
                if(cham.name[j]==v_job[i][k]){
                    if(i==0){
                     cham.synerge[j][cham.synerge[j].length]="결투가"; 
                     }
                    if(i==1){
                        cham.synerge[j][cham.synerge[j].length]="귀감";
                     }
                     if(i==2){
                        cham.synerge[j][cham.synerge[j].length]="명사수";
                     }
                     if(i==3){
                        cham.synerge[j][cham.synerge[j].length]="선봉대";
                     }
                     if(i==4){
                        cham.synerge[j][cham.synerge[j].length]="신비술사";
                     }
                     if(i==5){
                        cham.synerge[j][cham.synerge[j].length]="싸움꾼";
                     }
                     if(i==6){
                        cham.synerge[j][cham.synerge[j].length]="암살자";
                     }
                     if(i==7){
                        cham.synerge[j][cham.synerge[j].length]="요술사";
                     }
                     if(i==8){
                        cham.synerge[j][cham.synerge[j].length]="조율자";
                     }
                     if(i==9){
                        cham.synerge[j][cham.synerge[j].length]="처형자";
                     }
                     if(i==10){
                        cham.synerge[j][cham.synerge[j].length]="학살자";
                     }
                     if(i==11){
                        cham.synerge[j][cham.synerge[j].length]="흡수자";
                     }
                }
                // if(cham.)
            }
        }
     }
 }
 f_jobsynerge();
//  console.log(cham)