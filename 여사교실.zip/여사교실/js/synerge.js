var synergies = [];
var line ={};
var job = {};



